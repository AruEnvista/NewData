package com.landmarkgroup.api.returnpolicyenquiry;

import com.landmarkgroup.api.returnpolicyenquiry.mapper.BusinessMapper;
import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderLines;
import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.repository.SalesOrderRepository;
import com.landmarkgroup.api.returnpolicyenquiry.service.ReturnPolicyValidationService;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;
import java.util.Arrays;

@RunWith(SpringRunner.class)
@WebFluxTest
class ReturnPolicyEnquiryApplicationTests {

	@Autowired
	private WebTestClient webTestClient;

	@MockBean
	private ReturnPolicyValidationService returnPolicyValidationService;

	@Test
	public void orderNotFound() {
		ExternalOrderRequest request = new ExternalOrderRequest();
		request.setCustomerOrderId ("009009943");
		request.setEnterpriseCode ("LMG_UAE / LMG_BAH");
		request.setSource ( "HYBRIS / POS" );
		ExternalOrderLines lines = new ExternalOrderLines();
		lines.setItemId ( "10000000" );
		request.setOrderLines ( Arrays.asList (lines) );

        Mono<ExternalOrderRequest> monod1= Mono.just(request);
        Mono<ResponseEntity<ExternalOrderRequest>> d = monod1.map ( o1 -> ResponseEntity.status ( HttpStatus.OK ).body ( o1 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () );


        System.out.println("data is"+
                returnPolicyValidationService.validateOrderForReturns ( request.getCustomerOrderId(),request ));

		Mockito.when(returnPolicyValidationService
				.validateOrderForReturns ( request.getCustomerOrderId(),request ))
                .thenReturn (  d );

		webTestClient.get()
				.uri("/v3/customer-orders/9099909/events/return-refund-enquiry")
				.exchange()
				.expectStatus().isNotFound ();

	}

    @Test
    public void automateAPI() {
        ExternalOrderRequest request = new ExternalOrderRequest();
        request.setCustomerOrderId ("0090043");
        request.setEnterpriseCode ("LMG_UAE");
        request.setSource ( "HYBRIS" );
        ExternalOrderLines lines = new ExternalOrderLines();
        lines.setItemId ( "10000000" );
        lines.setMaximumReturnableQuantity ( new java.math.BigDecimal(2 ));
        request.setOrderLines ( Arrays.asList (lines) );

		  Mockito.when ( returnPolicyValidationService.validateOrderForReturns (Mockito.any(String.class) ,Mockito.any ( ExternalOrderRequest.class )) )
				.thenReturn ( Mono.just ( request ).map ( o1 -> ResponseEntity.status ( HttpStatus.OK ).body ( o1 ) ).defaultIfEmpty ( ResponseEntity.notFound ().build () ));

		 String res = webTestClient.post ()
				.uri ( "/v3/customer-orders/{customer-order-id}/events/return-policy-enquiry", "0090043" )
				.body ( Mono.just ( request ), ExternalOrderRequest.class )
				 .accept(MediaType.APPLICATION_JSON_UTF8)
				.exchange ()
				.expectBody ( ExternalOrderRequest.class )
				.returnResult ().getResponseBody ().getCustomerOrderId ();
		         //Assert.assertEquals (res ,"0090043");
    }
}



