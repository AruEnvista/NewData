package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnpolicydb")
public class SalesOrderResponse {

    @NonNull
    @Field("enterprise_code")
    private String enterpriseCode;

    @Field("document_type")
    private BigDecimal documentType;

    @Field("order_date")
    private String orderDate;

    @Field("source")
    private String source;

    @Field("isRTS")
    private boolean isRTS = false;

    @Field("is_guest_user")
    private boolean isGuestUser = false;

    @Field("shukran_loyalty_card_no")
    private String shukranLoyaltyCardNo;

    @NonNull
    @Field("order_number")
    private String orderNumber;

    @Field("order_lines")
    private List<SalesOrderLines> orderLines;

    @Field("header_charges")
    private List<HeaderCharge> headerCharges;

    @Field("header_taxes")
    private List<HeaderTax> headerTaxes;

    @Field("payment_methods")
    private List<PaymentMethod> paymentMethods;

    @Field("isLegacyOrder")
    private Boolean isLegacyOrder=false;

    @Field("statusList")
    private List<String> statusList ;

}
