package com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalOrderRequest {
    @NonNull
    @JsonProperty("customer_order_id")
    private String customerOrderId;

    @NonNull
    @JsonProperty("enterprise_code")
    private String enterpriseCode;

    private String status;

    @NonNull
    private String source;

    @JsonProperty("is_legacy_order")
    private boolean isLegacyOrder=false;

    @JsonProperty("is_manager_override")
    private boolean isManagerOverride=false;

    @JsonProperty("order_lines")
    private List<ExternalOrderLines> orderLines;
}


