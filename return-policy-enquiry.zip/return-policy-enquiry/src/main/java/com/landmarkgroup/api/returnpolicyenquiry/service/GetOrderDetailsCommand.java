package com.landmarkgroup.api.returnpolicyenquiry.service;

import org.springframework.http.HttpMethod;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.net.URISyntaxException;

public class GetOrderDetailsCommand implements ServiceCommandInterface {

    private String otherUrl = "";

    public GetOrderDetailsCommand(String otherUrl) {
        this.otherUrl = otherUrl;
    }

    @Override
    public Object Execute() throws URISyntaxException {
        WebClient.RequestHeadersSpec<?> client = WebClient.create()
                .method(HttpMethod.GET)
                .uri(URI.create(""))
                .body(BodyInserters.fromObject("data"), String.class);

        return null;

    }
}
