package com.landmarkgroup.api.returnpolicyenquiry.repository;

import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.OmsReturnOrder;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface ReturnOrderRepository extends ReactiveMongoRepository<OmsReturnOrder, String>{
    Flux<OmsReturnOrder> findByReturnOrderNumber(String orderNumber) ;
}


