package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnOrderDB")
public class OmsReturnOrder {
    @NonNull
    @Field("return_order_number")
    private String returnOrderNumber;

    @Field("enterprise_code")
    private String enterpriseCode;

    @NonNull
    @Field("return_order_status")
    private String returnOrderStatus;

    @NonNull
    @Field("return_order_date")
    private String returnOrderDate;

    @NonNull
    @Field("refund_initiated_flag")
    private String refundInitiatedFlag;

    @Field("order_lines")
    private List<ReturnOrderLines> orderLines;

    @Field("source")
    private String source;
}
