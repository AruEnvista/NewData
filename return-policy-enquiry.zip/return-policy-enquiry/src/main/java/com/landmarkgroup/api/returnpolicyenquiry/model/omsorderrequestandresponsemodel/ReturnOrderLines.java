package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnOrderDB")
public class ReturnOrderLines {
    @NonNull
    @Field("item_identifier")
    private String itemIdentifier;

    @NonNull
    @Field("line_status")
    private String lineStatus;

    @NonNull
    @Field("return_quantity")
    private BigDecimal returnQuantity;

}
