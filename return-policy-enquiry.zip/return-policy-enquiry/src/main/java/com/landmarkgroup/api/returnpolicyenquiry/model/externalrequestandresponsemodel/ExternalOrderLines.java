package com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class ExternalOrderLines {
    @NonNull
    @JsonProperty("item_id")
    private String itemId;

    @JsonProperty("item_description")
    private String itemDescription;

    @JsonProperty("maximum_returnable_quantity")
    private BigDecimal maximumReturnableQuantity;

    @JsonProperty("is_returnable")
    private boolean isReturnable=false;

    @JsonProperty("with_in_return_window")
    private boolean withInReturnWindow=false;

    @JsonProperty("return_window_period")
    private BigDecimal returnWindowPeriod;

    @NonNull
    @JsonProperty("ordered_quantity")
    private BigDecimal orderedQuantity;

    @NonNull
    @JsonProperty("department_code")
    private String departmentCode;

    @JsonProperty("delivery_type")
    private String deliveryType;
}
